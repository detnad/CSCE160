import information

my_contact_info = information.Information("Desait","Mplampla 12, Thessaloniki","35","6932319480")
mom = information.Information('Mom', 'Mplampla 26','62','6936859656')
dad = information.Information('Dad', 'Mpilpl 33', '83','235423535123')
