# starting-out-with-python-global-4th-edition
Exercises for the book Starting out with Python 4th edition.
